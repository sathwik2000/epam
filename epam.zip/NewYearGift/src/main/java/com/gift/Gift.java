package com.gift;

interface Gift {
public void setInfo();
public void getInfo();
}
